import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class QuizMaker {
    public static void main(String[] args) throws FileNotFoundException, InvalidQuizFormatException {
        Quiz quiz = new Quiz();
        quiz.start();
    }
}
