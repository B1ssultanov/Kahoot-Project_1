import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Quiz {
    String name;
    ArrayList<String> questions = new ArrayList<>();
    File file = new File("C:\\Users\\user\\Documents\\Kahoot\\src\\Quiz");

    public void setName(String name) {this.name = file.getName();}
    public String getName() {return name;}
    public void addQuestion(ArrayList Question){
        questions.add(String.valueOf(Question));
    }
    public Quiz loadFromFile(String name) throws InvalidQuizFormatException {
        Quiz quiz = new Quiz();
        File file1 = new File("C:\\Users\\user\\Documents\\Kahoot\\src\\"+name);
        if ( file1.exists() ){
            return quiz;
        }
        else{
            throw new InvalidQuizFormatException();
        }
    }

    @Override
    public String toString() {
        return "Quiz{name='" + name + '\'' + ", questions=" + questions + '}';
    }

    public void start() throws FileNotFoundException {

        Scanner sc = new Scanner(file);
        Scanner UI = new Scanner(System.in);
        double score = 0, fails = 0;

        System.out.println("WELCOME TO \"" + file.getName() + "\" QUIZ!");
        System.out.println("_______________________________________________");

        while(sc.hasNextLine()) {
            String description = sc.nextLine();
            System.out.println(description);
            if (description.contains("________")) {
                FillIn fillIn = new FillIn();
                fillIn.setDescription(description);
                fillIn.setAnswer(sc.nextLine());

                System.out.print("----------------------\n" + "Type your answer: ");
                String UA = UI.nextLine();

                if (UA.equals(fillIn.getAnswer())) {
                    System.out.println("Correct!");
                    System.out.println("_______________________________________________");
                    score++;
                } else {
                    System.out.println("Incorrect!");
                    fails++;
                }
            } else {
                Test test = new Test();
                test.setDescription(description);

                String[] options = new String[1000];
                for (int i = 0; i < 4; ++i) {
                    options[i] = sc.nextLine();
                }
                test.setAnswer(options[0]);
                test.setOptions(options);

                for ( int i = 0 ; i < 4 ; ++i ){
                    System.out.println((char)('A' + i) + ") " + test.getOptionAt(i));
                }

                System.out.print("----------------------\n" + "Enter the correct choice: ");
                char UA = UI.nextLine().charAt(0);
                int cind = UA - 'A';

                while ( cind < 0 || cind > 3 ){
                    System.out.print("Invalid choice! Try again (Ex: A, B, C, D): ");
                    UA = UI.nextLine().charAt(0);
                    cind = UA - 'A';
                }

                if (test.getOptionAt(cind).equals(test.getAnswer())) {
                    System.out.println("Correct!");
                    System.out.println("_______________________________________________");
                    score++;
                } else {
                    System.out.println("Incorrect!");
                    fails++;
                }
            }
            sc.nextLine();
        }
        double ans = (100*score)/(fails+score);
        System.out.println("Correct Answers: " + (int)score + "/" + (int)(fails+score) + "(" + ans + "%)");
    }
}
