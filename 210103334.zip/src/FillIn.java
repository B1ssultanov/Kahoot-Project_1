public class FillIn extends Question{

    @Override
    public String toString() {
        return getDescription();
    }
}
