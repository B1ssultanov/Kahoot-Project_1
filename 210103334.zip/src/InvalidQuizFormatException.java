public class InvalidQuizFormatException extends Throwable {
    public String InvalidQuizFormatException(){
        return "Such a file does not exists!";
    }
}
